from Soul import Exp_Encyclopedia

class Judge():
    def __init__(self):
        pass